from pipelines.chat import generate_response
from pipelines.tts import synthesize
from pipelines.avatar import generate_avatar

def render(prompt: str):
    response = generate_response(prompt)

    wav = synthesize(
        text=response,
        output_path="input/eila.wav"
    )

    video = generate_avatar(
        audio_path=wav,
        avatar_path="assets/avatars/eila/avatar.jpg"
    )

    return {
        "response": response,
        "audio": wav,
        "video": video
    }
