import subprocess
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
MUSE = ROOT / "repos" / "MuseTalk"

CACHE = ROOT / "cache"
CACHE.mkdir(exist_ok=True)

def generate_avatar(audio_path: str, avatar_path: str):

    config = {
        "task_0": {
            "video_path": str((ROOT / avatar_path).resolve()),
            "audio_path": str((ROOT / audio_path).resolve()),
            "result_name": "eila.mp4",
            "bbox_shift": -7,
        }
    }

    config_path = CACHE / "runtime.yaml"

    with open(config_path, "w") as f:
        yaml.safe_dump(config, f)

    env = dict(**__import__("os").environ)
    env["TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD"] = "1"

    subprocess.run(
        [
            "python3",
            "-m",
            "scripts.inference",
            "--inference_config",
            str(config_path),
            "--result_dir",
            "results/test",
            "--unet_model_path",
            "models/musetalkV15/unet.pth",
            "--unet_config",
            "models/musetalkV15/musetalk.json",
            "--version",
            "v15",
        ],
        cwd=MUSE,
        env=env,
        check=True,
    )

    mp4 = next(
        MUSE.glob("results/test/v15/*.mp4"),
        None
    )

    if mp4 is None:
        raise RuntimeError("MuseTalk produced no video.")

    return str(mp4)
