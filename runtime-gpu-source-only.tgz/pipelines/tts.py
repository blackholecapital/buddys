from pathlib import Path

def synthesize(text: str, output_path: str):
    print(f"TTS: {text}")

    wav = Path("input/eila.wav")

    if not wav.exists():
        raise FileNotFoundError(wav)

    return str(wav)
