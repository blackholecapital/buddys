import requests

OLLAMA="http://127.0.0.1:11434/api/generate"
MODEL="qwen2.5-coder:14b"

def generate_response(prompt):
    r=requests.post(OLLAMA,json={
        "model":MODEL,
        "prompt":prompt,
        "stream":False
    },timeout=120)
    r.raise_for_status()
    return r.json()["response"]
