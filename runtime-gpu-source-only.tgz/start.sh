#!/bin/bash
export TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD=1

echo "================================="
echo " Alley AI Runtime GPU"
echo "================================="

python3 health.py

exec uvicorn server:app \
    --host 0.0.0.0 \
    --port 8000
