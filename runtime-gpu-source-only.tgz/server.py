from fastapi import FastAPI
from pydantic import BaseModel

from pipelines.render import render

app = FastAPI(title="Alley AI Runtime")

class RenderRequest(BaseModel):
    prompt: str

@app.get("/health")
async def health():
    return {"status":"ok"}

@app.post("/render")
async def render_api(req: RenderRequest):
    return render(req.prompt)
